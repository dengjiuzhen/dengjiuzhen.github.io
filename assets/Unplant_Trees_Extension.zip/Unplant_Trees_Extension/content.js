// Unplant Trees Extension

console.log("Unplant Trees extension is running!");

// ===========================================
// Detect AI Overview
// ===========================================

const observer = new MutationObserver(() => {
  const aiBlock = document.querySelector('div.Kevs9');

console.log("MutationObserver is now watching the page...");
  console.log("Mutation found... checking for AI block");

  if (aiBlock) {
    console.log("AI block found:", aiBlock);
  } else {
    console.log("AI block not found yet");
  }

  if (aiBlock && !document.querySelector('.tree-overlay')) {
    console.log("No overlay yet → adding trees");
    addTrees(aiBlock);
  } else if (document.querySelector('.tree-overlay')) {
    console.log("Overlay already exists, skipping");
  }
});
observer.observe(document.body, {
  childList: true,
  subtree: true
});

console.log("MutationObserver is now watching the page...");

// ===========================================
// Create Tree Overlay
// ===========================================
function addTrees(aiBlock) {
  console.log("Creating overlay...");

  const rect = aiBlock.getBoundingClientRect();

  const overlay = document.createElement('div');
  overlay.className = 'tree-overlay';

  // Correct positioning
  overlay.style.position = 'absolute';
  overlay.style.top = `${rect.top + window.scrollY}px`;
  overlay.style.left = `${rect.left + window.scrollX}px`;
  overlay.style.width = `${rect.width}px`;
  overlay.style.height = `${rect.height}px`;

  overlay.style.zIndex = '9999';
  overlay.style.pointerEvents = 'none';

  overlay.style.background = 'rgba(0,255,0,0.1)';

  document.body.appendChild(overlay);

  console.log("Overlay positioned:", overlay);

  generateTrees(overlay, rect.height);
}

// ===========================================
//Plant Trees
// ===========================================
function generateTrees(container, height) {
  console.log("Generating fence of trees...");

  container.style.display = 'flex';
  container.style.alignItems = 'flex-end';
  container.style.justifyContent = 'flex-start';
  container.style.gap = '4px';
  container.style.overflow = 'hidden';

  const containerWidth = container.offsetWidth;

  const estimatedTreeWidth = height * 0.6; 
  const treeCount = Math.ceil(containerWidth / estimatedTreeWidth);

  console.log(`Container height: ${height}px`);
  console.log(`Tree count: ${treeCount}`);

  for (let i = 0; i < treeCount; i++) {
    const tree = document.createElement('img');

    tree.src = chrome.runtime.getURL('images/tree_full.png');
    tree.className = 'tree';
    tree.dataset.state = 'full';
    tree.dataset.clicks = 0;

    tree.style.height = '100%';
    tree.style.width = 'auto';
    tree.style.objectFit = 'contain';


    tree.style.pointerEvents = 'auto';
    tree.style.cursor = 'pointer';

    const scale = 0.9 + Math.random() * 0.2;
    const rotate = Math.random() * 4 - 2;
    tree.style.transform = `scale(${scale}) rotate(${rotate}deg)`;

    tree.addEventListener('click', () => handleTreeClick(tree));

    container.appendChild(tree);
  }

  console.log("Tree fence created!");
}

// ===========================================
//Unplant 2 Click
// ===========================================
function handleTreeClick(tree) {
  let clicks = parseInt(tree.dataset.clicks);
  clicks++;

  tree.dataset.clicks = clicks;

  console.log(`Tree clicked! Total clicks: ${clicks}`);

  if (clicks === 1) {
  console.log("First cut → changing to cut tree");

  const rect = tree.getBoundingClientRect();

  tree.style.width = `${rect.width}px`;
  tree.style.height = `${rect.height}px`;

  tree.style.flexShrink = '0';

  // keep bottom alignment
  tree.style.alignSelf = 'flex-end';

  // swap image
  tree.src = chrome.runtime.getURL('images/tree_cut.png');
} else if (clicks >= 2) {
    console.log("Tree removed!");
    tree.remove();
  }
}